# 🏠 F4Prop

## BCIT QDS20 Hackathon

### What did we make?
A tool to inform the general user whether if their property may be 
affected by the following factors:
- Crime
- Bus Stop
- Shelters

## Team Members
* Ken
* Loai
* Leon
* David

## Technologies Being Used:
* React
* Power BI
