import React from 'react';

const Graph = ({ image }) => {
  return (
    <div>
      <img src={image} style={{ height: '14rem', width: '18rem' }} />
    </div>
  );
};

export default Graph;
