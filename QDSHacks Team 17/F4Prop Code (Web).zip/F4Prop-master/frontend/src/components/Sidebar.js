import React, { Component } from 'react';
import { Menu, Icon, Button, Input, Layout, Checkbox } from 'antd';
const { SubMenu } = Menu;

const CheckboxGroup = Checkbox.Group;

const { Search } = Input;
const plainOptions = ['Crime', 'Bus Stop', 'Shelter'];
const defaultCheckedList = ['Apple', 'Orange'];
const { Header, Content, Sider } = Layout;

class Sidebar extends Component {
  state = {
    collapsed: false
  };

  onCollapse = collapsed => {
    console.log(collapsed);
    this.setState({ collapsed });
  };

  onCheck = e => {
    this.props.displayGraph(e.target.value);
  };

  render() {
    return (
      <Sider
        collapsible
        collapsed={this.state.collapsed}
        onCollapse={this.onCollapse}
        style={{ backgroundColor: 'white' }}
      >
        <div className="logo" />
        <Menu mode="inline">
          <Menu.Item key="1">
            <Search
              placeholder="Address"
              onSearch={value => console.log(value)}
              enterButton
              style={{ margin: '2px 0' }}
            />
          </Menu.Item>
          <SubMenu
            key="sub1"
            title={
              <span>
                <Icon type="funnel-plot" />
                <span>Filter</span>
              </span>
            }
          >
            <Menu.Item key="3">
              <Checkbox defaultChecked={true} onChange={() => this.onCheck}>
                Crime
              </Checkbox>
            </Menu.Item>
            <Menu.Item key="4">
              <Checkbox defaultChecked={true} onChange={() => this.onCheck}>
                Shelter
              </Checkbox>
            </Menu.Item>
            <Menu.Item key="5">
              <Checkbox defaultChecked={true} onChange={() => this.onCheck}>
                Bus Stop
              </Checkbox>
            </Menu.Item>
          </SubMenu>
          <SubMenu
            key="sub2"
            title={
              <span>
                <Icon type="setting" />
                <span>Options</span>
              </span>
            }
          >
            <Menu.Item key="6">
              <Icon type="star" />
              Premium
            </Menu.Item>
          </SubMenu>
        </Menu>
      </Sider>
    );
  }
}

export default Sidebar;
