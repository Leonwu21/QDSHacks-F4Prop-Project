import React, { Component } from 'react';
import './Landing.css';
import image from './buildings.jpg';
import ReactFullpage from '@fullpage/react-fullpage';
import { Input } from 'antd';
import { Col, Row } from 'antd';
import description from './description.png';

const { Search } = Input;

const Landing = props => (
  <ReactFullpage
    scrollingSpeed={1000} /* Options here */
    sectionsColor={['orange', 'white', 'green']}
    render={({ state, fullpageApi }) => {
      return (
        <ReactFullpage.Wrapper>
          <div className="section section1">
            <h3
              style={{
                color: 'white',
                position: 'absolute',
                top: '20px',
                left: '20px',
                fontSize: '28px',
                fontWeight: 'bold'
              }}
            >
              F4Prop
            </h3>
            <h1
              className="title"
              style={{ marginBottom: '5rem', fontSize: '64px' }}
            >
              Find out which factors are
              <br /> affecting your property below...
            </h1>
            <Search
              placeholder="Search"
              enterButton="Search"
              style={{ width: 400, height: 100 }}
              onSearch={value => {
                // value = value.replace(/\s/g, '+');
                props.history.push(`/result`);
              }}
            />
            <button
              style={{
                margin: '5rem auto auto',
                borderRadius: '3rem',
                width: '10rem'
              }}
              onClick={() => fullpageApi.moveSectionDown()}
            >
              Description
            </button>
          </div>
          <div className="section section3">
            <Row>
              <Col span={12}>
                <div>
                  <img
                    src={description}
                    alt="image1"
                    style={{ height: '20rem', width: '28rem' }}
                  />
                </div>
              </Col>
              <Col span={12}>
                <h3 style={{}}>What does our app do?</h3>
                <p
                  style={{
                    color: 'black',
                    width: '20rem',
                    margin: '3rem auto'
                  }}
                >
                  We help public users understand and predict the changing costs
                  of real estate based on specific factors
                </p>
                <button
                  style={{ margin: '5rem auto' }}
                  onClick={() => fullpageApi.moveTo(1, 0)}
                >
                  Move to Top
                </button>
              </Col>
            </Row>
          </div>
        </ReactFullpage.Wrapper>
      );
    }}
  />
);

export default Landing;
