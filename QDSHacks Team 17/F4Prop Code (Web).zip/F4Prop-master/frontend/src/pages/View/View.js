import React, { Component } from 'react';
import { Col, Row, Layout, Menu, Icon } from 'antd';
import { Input } from 'antd';
import './View.css';
import { Checkbox } from 'antd';
import Sidebar from '../../components/Sidebar';
import map from './map.png';
import Graph from '../../components/Graph';

import image1 from './crime.png';
import image2 from './shelters.png';
import image3 from './transit.png';

const CheckboxGroup = Checkbox.Group;

const { Header, Content, Footer, Sider } = Layout;
const { SubMenu } = Menu;

const plainOptions = ['Crime', 'Bus Stop', 'Shelter'];
const defaultCheckedList = ['Apple', 'Orange'];
const { Search } = Input;

class View extends Component {
  state = {
    collapsed: false,
    crime: true,
    shelter: true,
    bus: true
  };

  onCollapse = collapsed => {
    console.log(collapsed);
    this.setState({ collapsed });
  };
  render() {
    return (
      <Layout style={{ minHeight: '100vh' }}>
        <Header className="header">
          <h1
            style={{
              fontSize: '25px',
              color: 'white',
              fontWeight: 'bold',
              position: 'absolute',
              top: '15px',
              left: '30px'
            }}
          >
            F4Prop
          </h1>
          <Menu
            theme="dark"
            mode="horizontal"
            defaultSelectedKeys={['2']}
            style={{ lineHeight: '64px', float: 'right' }}
          >
            <Menu.Item key="1" style={{ position: 'relative', left: '2rem' }}>
              <Icon
                type="home"
                style={{
                  fontSize: '25px',
                  position: 'relative',
                  left: '5px'
                }}
                onClick={() => this.props.history.push('/')}
              />
            </Menu.Item>
          </Menu>
        </Header>
        <Layout>
          <Sidebar />
          <Layout>
            <Content
              style={{
                background: '#fff',
                margin: 0,
                height: '100%'
              }}
            >
              <img
                src={map}
                style={{
                  objectFit: 'cover',
                  height: '60vh',
                  width: '100%'
                }}
              />
              <Row
                style={{ position: 'relative', right: '4rem' }}
                type="flex"
                justify="space-around"
              >
                {this.state.crime ? (
                  <Col span={3}>
                    <Graph image={image1} />
                  </Col>
                ) : null}
                {this.state.crime ? (
                  <Col span={3}>
                    <Graph image={image2} />
                  </Col>
                ) : null}
                {this.state.crime ? (
                  <Col span={3}>
                    <Graph image={image3} />
                  </Col>
                ) : null}
              </Row>
            </Content>
          </Layout>
        </Layout>
      </Layout>
    );
  }
}

export default View;
